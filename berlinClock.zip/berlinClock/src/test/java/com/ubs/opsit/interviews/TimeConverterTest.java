package com.ubs.opsit.interviews;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import static org.hamcrest.core.Is.is;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 *
 * @author apali
 */
public class TimeConverterTest {

    TimeConverter timeConverter = null;

    public TimeConverterTest() {
    }

    @Before
    public void setUp() {
        timeConverter = new TimeConverterImpl();
    }

    @Test
    public void testConvertTimeSomeValue() {
        Assert.assertNotSame(timeConverter.convertTime("00:00:00"), ("Please enter valid time"));
    }

    @Test
    public void testConvertTimeNullvalue() {
        Assert.assertThat(timeConverter.convertTime(""), is("Please enter valid time"));
    }
    
    @Test
    public void testConvertTimeMidnight() {
        String [] lines = timeConverter.convertTime("00:00:00").split("\\n");
        Assert.assertThat(lines[0], is ("Y"));
        Assert.assertThat(lines[1], is ("OOOO"));
        Assert.assertThat(lines[2], is ("OOOO"));
        Assert.assertThat(lines[3], is ("OOOOOOOOOOO"));
        Assert.assertThat(lines[4], is ("OOOO"));
    }
    
    @Test
    public void testConvertTimeMiddleAfternoon() {
        String [] lines = timeConverter.convertTime("13:17:01").split("\\n");
        Assert.assertThat(lines[0], is ("O"));
        Assert.assertThat(lines[1], is ("RROO"));
        Assert.assertThat(lines[2], is ("RRRO"));
        Assert.assertThat(lines[3], is ("YYROOOOOOOO"));
        Assert.assertThat(lines[4], is ("YYOO"));
    }
    
    @Test
    public void testConvertTimeBeforeMidnight() {
        String [] lines = timeConverter.convertTime("23:59:59").split("\\n");
        Assert.assertThat(lines[0], is ("O"));
        Assert.assertThat(lines[1], is ("RRRR"));
        Assert.assertThat(lines[2], is ("RRRO"));
        Assert.assertThat(lines[3], is ("YYRYYRYYRYY"));
        Assert.assertThat(lines[4], is ("YYYY"));
    }
    
    @Test
    public void testConvertTimeMidnight_2() {
        String [] lines = timeConverter.convertTime("24:00:00").split("\\n");
        Assert.assertThat(lines[0], is ("Y"));
        Assert.assertThat(lines[1], is ("RRRR"));
        Assert.assertThat(lines[2], is ("RRRR"));
        Assert.assertThat(lines[3], is ("OOOOOOOOOOO"));
        Assert.assertThat(lines[4], is ("OOOO"));
    }
}
