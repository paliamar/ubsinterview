/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ubs.opsit.interviews;

/**
 *
 * @author amar
 */
public class HourConverter {

    String getFirstRowHours(int p20Hrs) {

        StringBuilder firstRow = new StringBuilder();
        for (int i = 0; i < (p20Hrs / 5); i++) {
            firstRow.append("R");
        }
        int i = firstRow.lastIndexOf("R");
        getHours(i, firstRow);
        return firstRow.toString();
    }

    String getSecondRowHours(int p4Hrs) {
        StringBuilder secondRow = new StringBuilder();
        for (int i = 0; i < (p4Hrs % 5); i++) {
            secondRow.append("R");
        }
        int i = secondRow.lastIndexOf("R");
        getHours(i, secondRow);
        return secondRow.toString();
    }

    private void getHours(int i, StringBuilder secondRow) {
        switch (i) {
            case -1:
                secondRow.append("OOOO");
                break;
            case 0:
                secondRow.append("OOO");
                break;
            case 1:
                secondRow.append("OO");
                break;
            case 2:
                secondRow.append("O");
                break;
            default:
                break;
        }
    }
}
