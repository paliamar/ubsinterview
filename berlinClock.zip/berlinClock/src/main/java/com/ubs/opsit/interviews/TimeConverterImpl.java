/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ubs.opsit.interviews;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author amar
 */
public class TimeConverterImpl implements TimeConverter {

    private static final Logger LOG = LoggerFactory.getLogger(TimeConverterImpl.class);

    @Override
    public String convertTime(String aTime) {
        StringBuilder convertedTime = new StringBuilder();
        HourConverter hourConverter = new HourConverter();
        MinuteConverter minuteConverter = new MinuteConverter();
        String[] timeConvert = null;
        if (aTime == null || aTime.isEmpty()) {
            return "Please enter valid time";
        } else {
            if (aTime != null && !aTime.isEmpty() && aTime.length() == 8) {
                timeConvert = aTime.split(":");
            }
        }

        int hours = 00;
        int minute = 00;
        int second = 00;
//        LOG.info("com.ubs.opsit.interviews.TimeConverterImpl.convertTime() =>" + aTime + "Length  =>"+timeConvert.length);
        if (timeConvert != null && timeConvert.length == 3) {
            hours = Integer.parseInt(timeConvert[0]);
            minute = Integer.parseInt(timeConvert[1]);
            second = Integer.parseInt(timeConvert[2]);
            
        }
        convertedTime.append(getTopRow(second % 2 == 0));
        convertedTime.append("\n");
        convertedTime.append(hourConverter.getFirstRowHours(hours));
        convertedTime.append("\n");
        convertedTime.append(hourConverter.getSecondRowHours(hours));
        convertedTime.append("\n");
        convertedTime.append(minuteConverter.getThirdRowMins(minute));
        convertedTime.append("\n");
        convertedTime.append(minuteConverter.getFourthRowMins(minute));

//        System.out.println("First ==> " + getTopRow(second % 2 == 0));
//        System.out.println("Second ==> " + hourConverter.getSecondRowHours(hours));
//        System.out.println("Third ==> " + hourConverter.getFirstRowHours(hours));
//        System.out.println("Fourth ==>" + minuteConverter.getThirdRowMins(minute));
//        System.out.println("Fifth ==> " + minuteConverter.getFourthRowMins(minute));

        return convertedTime.toString();
    }

    private String getTopRow(Boolean pOnOff) {
        String onOff = null;
        if (pOnOff) {
            onOff = "Y";
        } else {
            onOff = "O";
        }
        return onOff;
    }

}
