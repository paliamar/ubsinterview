/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ubs.opsit.interviews;

/**
 *
 * @author amar
 */
public class MinuteConverter {
    
    protected String getThirdRowMins(int pMins) {
        return getMinute(11, (pMins - (pMins % 5)) / 5, "Y").replaceAll("YYY", "YYR");
    }

    protected String getFourthRowMins(int pMins) {
        return getMinute(4, pMins % 5, "Y");
    }

    private String getMinute(int noOfMinute, int minute, String minuteChar) {
        String out = "";
        for (int i = 0; i < minute; i++) {
            out += minuteChar;
        }
        for (int i = 0; i < (noOfMinute - minute); i++) {
            out += "O";
        }
        return out;
    }
    
}
