package com.ubs.opsit.interviews;

public interface TimeConverter {

    String convertTime(String aTime);

}
