package com.ubs.opsit.interviews.example;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import org.junit.Test;

public class ExampleTest {

    @Test
    public void thisTestShouldPassIfYouHaveEverythingIsSetupCorrectly() {
        new Example().sayHi();
        assertThat(true, is(true));
    }
    
    @Test
    public void testStr() {
                String str = "R";
        int i  = str.lastIndexOf("R");
        System.out.println("*************************==>" +0%5);
    }
}
